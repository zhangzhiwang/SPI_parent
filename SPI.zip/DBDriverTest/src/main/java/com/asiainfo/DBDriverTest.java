package com.asiainfo;

import java.util.ServiceLoader;

/**
 * 测试SPI
 *
 * @author zhangzhiwang
 * @date Jun 30, 2020 10:20:22 AM
 */
public class DBDriverTest {
	public static void main(String[] args) {
		ServiceLoader<MyDBDriver> serviceLoader = ServiceLoader.load(MyDBDriver.class);
		for(MyDBDriver driver : serviceLoader) {
			String connection = driver.getConnection("localhost");
			System.out.println(connection);
		}
	}
}
