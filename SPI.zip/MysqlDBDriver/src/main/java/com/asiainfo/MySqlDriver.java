package com.asiainfo;

public class MySqlDriver implements MyDBDriver {

	public String getConnection(String s) {
		// TODO Auto-generated method stub
		return "mysql driver : " + s;
	}

}
