package com.asiainfo;

/**
 * SPI（Service Provider Interface），就是将接口和实现分离，只定义接口而不定义实现，实现由第三方来提供。
 * 比如jdk的数据库驱动java.sql.Driver类，jdk只提供接口规范，实现类由第三方厂商提供，比如mysql、oracle等。
 * 体现了设计模式中的策略模式，也体现了面向接口编程，客户端是面向接口编程的，更改底层的实现模块不会导致客户端的改变。
 * 
 * SPI对实现类的约定：
 * 1、实现类必须在其工程的classpath下面创建目录META-INF/services（目录名称不可改变）
 * 2、在上面的目录下创建文件，文件名是接口的全限定名，内容是工程实现此接口的实现类的全限定名
 * 3、在调用方使用ServiceLoader.load()方法来加载驱动
 *
 * @author zhangzhiwang
 * @date Jun 30, 2020 10:50:51 AM
 */
public interface MyDBDriver {// 只提供接口不提供实现
	String getConnection(String s);
}
