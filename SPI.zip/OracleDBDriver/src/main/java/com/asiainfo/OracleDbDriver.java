package com.asiainfo;

public class OracleDbDriver implements MyDBDriver {

	public String getConnection(String s) {
		// TODO Auto-generated method stub
		return "oracle driver : " + s;
	}
}
